<?php
// Created by Hao Zhang


	sleep(3);
    
	print "Hello AJAX!";
?>