<?php
// Created by Hao Zhang

    
    $me = array("name" => "Mr. Wergeles", "pet" => "Tiger", "nick" => "yes nick");

    print json_encode($me);

?>