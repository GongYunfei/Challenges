<!DOCTYPE html>
<!-- Created by Hao Zhang -->
<html>
<head>
	<title>First PHP</title>
</head>
	<body>

	<h1>My first PHP page</h1>

	<?php
		echo "Hello World! Printed from PHP";
	?>

	</body>
</html>